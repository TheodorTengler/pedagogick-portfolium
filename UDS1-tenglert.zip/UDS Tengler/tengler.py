#***************************************************
# file: bin2dec-dec2bin-v1.py
#
# bin number string to decimal value
# https://codinggear.blog/binary-to-decimal-python/
# employng Horner schema polynomial evaluation
#
# decimal integer to binary string
#
# ver. 2023-10-05
# modification by Petr Saloun
#***************************************************

def bin2dec(binary_str):
    digit_list = list(binary_str)
    sum = 0
    for digit in digit_list:
        sum = (sum * 2) + int(digit)
    return sum

def dec2bin(decimal):
    bn = ""
    while decimal > 0:
        bn = str(decimal % 2) + bn
        decimal = decimal // 2
    return bn

inp = input('Enter a Binary number to convert it to Decimal: ')
print(bin2dec(inp))

inp = int(input('Enter a Decimal integer number to convert it to Binary string: '))
print(dec2bin(inp))